ALPHONSE / ORCHESTRA ESTATE — ESSENTIAL FILES
Packaged 2 Aug 2026.

⭐ START HERE:
  Alphonse Build Handoff — CONDENSED.md  — THE WORKING STATE (12KB, use this daily).
  The Record Book.md                     — narrative log ("the Boob"), 11 entries.
  Alphonse Build Handoff — ARCHIVE.md     — the FULL old handoff (268KB). Only open if you
                                            need a superseded/historical detail. Do NOT load
                                            this into a chat by default — it's what caused crashes.

estate/phon.se/               — LIVE homepage + WhatsApp DP svg
estate/nil.sg/                — LIVE useless wing: gallery + 4 exhibits (null, bikes, friction, final)
estate/tools-and-records/
  how-i-think.md              — "The Operating Model" (the manual)
  observed-and-owned.html     — the antiphonal portrait (HELD draft, consultancy seed)
  the-record-book-living.html — the Gramophone reading engine
  private/sealed-survey.html  — SEALED Friday calibration instrument (private)

For a new chat: attach the CONDENSED handoff + The Record Book. Keep the ARCHIVE on disk only.
