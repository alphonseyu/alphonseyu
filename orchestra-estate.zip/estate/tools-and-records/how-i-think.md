# The Operating Model
### How one builder thinks and processes — observed from a slight remove

*A synthesis, drawn from the work itself rather than from anything declared.*

---

## The one line

**Reduce the *right* friction.** Everything below is a corollary of the word *right*. The instinct isn't to reduce friction — it's to first find out *which* friction is worth reducing, and leave the rest alone.

---

## How the thinking moves

**1. Question the requirement before building the solution.**
The reflex, faced with a task, isn't "how do I build this?" — it's "does this need to exist at all?" A three-password fortress gate got questioned down to two edits and a deploy, because the real threat model turned out to be "don't get indexed," not "stop a determined human." The most powerful move is often *dissolving* the work, not doing it. A fortress questioned is better than a fortress built.

**2. Lower the stakes until the thing can actually ship.**
Big framings paralyse; small ones move. A domain sat dormant for years under the weight of "a consultancy, a career pivot" — and shipped in an afternoon the moment it became "just a place to think." The serious question is the one that stops you; the unserious framing is what makes you build. This repeats everywhere: "just a blog," "redo the portrait haha," "just for fun." The joke is the delivery mechanism.

**3. Decide by gut; explain afterward.**
Decisions log as instinct first, rationale later — and the instinct is usually right. The tell is subtle: "let me think about it" almost always precedes the *correct* answer, because the gut has already spoken and the mind is catching up. When something feels too complex, that feeling *is* the verdict — no proof needed.

**4. Follow the spark, but hold it with discipline.**
Play is allowed to wander — a sideways-portrait joke became an emblem, a homepage, a reading engine, a named future project — but every wander ends in a deliberate stop. Things get *named and banked*, not force-built. The drawer holds sparks with discipline attached: each one has a reason and a moment, and none is dragged into existence before its time.

**5. Know when to stop.**
The rarest discipline, and the most consistent one here. "Enough Easter eggs already." "Enough friction for today." The craft isn't only in the making — it's in recognising when a good thing is *done* and resisting the urge to gild it. Stopping short and over-building are both failures; the skill is finding the exact line and standing on it.

---

## How the work gets built

**Structure over dates.** The mind runs on rhythm and recipe, not calendar. Things are numbered, not dated; organised by movement and suite, not by when they happened. *We live life forward but learn backward* — so a thought is kept for what it means, not filed by when it arrived.

**Systems thinking, through the people lens.** Not an engineer's systems-thinking — a *why-are-we-all-wasting-time-on-this* systems-thinking. The knack is spotting the thing quietly costing everyone effort, and preferring to build the fix than to talk about it.

**Timing as a designed variable.** Nothing important is rushed and nothing is late — it's *timed*. The biggest build waits for the exact moment the runway opens, down to the timestamp. Patience here isn't hesitation; it's a scheduled decision. Wait until you know what you want *and* have the room, then begin.

**Discover the thing's nature; don't impose a plan on it.** Repeatedly, what got built revealed what it *was* only after it existed — a settings screen turned out to be a meta-instrument, a gate turned out to be unnecessary, a joke turned out to be a homepage. The method isn't "design then execute"; it's "make it small, then listen to what it wants to become."

---

## How feedback and correction land

**Contrast is king, on every axis.** A way of seeing built from reading by luminance rather than colour — and it generalises into a design principle (signal by brightness and shape, never by hue) *and* keeps proving itself (text that vanished wasn't a colour problem, it was a light-vs-sunlight problem). The lesson the work keeps teaching its maker: the same principle, one more axis.

**Verify before assuming; look before spending.** Nothing is trusted to have worked just because it should have. Device-test the real thing. Check the balance before the fire. The cheap discipline that prevents the expensive mistake.

**Own the miss, keep the self-respect.** When something goes wrong, it's named plainly and turned into a logged lesson — no spiral, no over-apology. A wasted credit becomes "treat every send as a potential build," and the work moves on.

---

## The through-line

A builder who **reduces the right friction** — for others by trade, and slowly learning to do it for himself. Who **lowers the stakes** until the thing can ship, **trusts the gut** and explains later, **follows the spark** but **stops on time**, and **times the important things** rather than rushing them. Who builds small, listens to what the thing wants to become, and keeps contrast king on every axis.

*The subject appears to be conducting something. From this altitude it is difficult to say what — only that the parts move together, and that he does not seem to be in a hurry.*
