# ALPHONSE BUILD HANDOFF — ACTIVE (condensed 2 Aug 2026)

*The working state. Deep history + closed fires are in `Alphonse Build Handoff — ARCHIVE.md` (only open it if you need a superseded detail). This file is what's LIVE.*

---

## WHO / HOW
- **Rep** (répétiteur) works with **Alphonse** (+0800, mostly phone). Estate = **Orchestra**, a naming-world on **phon.se**.
- Motto: **"reduce the *right* friction."** Slogan: **"don't go off-tangent, be the tangent."**
- Two living records: **this handoff** (state) + **The Record Book** (narrative log, "the Boob", 1 entry/day, 11 entries).
- **⚠️ After saving ANY file, ALWAYS call present_files.** (Repeatedly forgotten — don't.)
- **⚠️ str_replace has EATEN "## Entry" headers in the Record Book — verify `grep -c "^## Entry"` after edits; prefer Python inserts for that file.**
- **⚠️ user_time_v0 is unreliable — use `TZ='Asia/Singapore' date` + confirm AM/PM with Alphonse.**

## LOVABLE BUILD RULES
- Symphon project ID: `9d25d8c6-074a-40a5-bec0-f56a55307740`.
- **Every send is a REAL build that commits — plan-mode flag does NOT hold.** Verify diffs; Alphonse device-tests after.
- Credits: **~5/day, reset 08:00 (+0800)**, until **18 Aug 3:22pm** when subscription renews → 100 credits land. **API NEVER returns balance** — Alphonse checks manually at lovable.dev/settings/billing.
- Fires are scoped, additive, diff-verified. Split big fires into sub-fires.

---

## ▶▶ NEXT: FIRE 8 (Wednesday, fully specced, blocker-free, ~2–3cr)
A small build fire (NOT the reassignment — that's a separate non-fire usage activity). All flows confirmed to exist → clean handler swaps:
1. **Date** → `EEE, dd MMM yyyy` = "Sun, 02 Aug 2026" (current header uses wrong format; house convention is dd MMM zero-padded).
2. **Etude invitation copy** → "Shape your experience" (was "Tune your settings" — clashed with Score's "Tune your structure").
3. **Remove redundant floating `+`** in bottom bar (header pill covers capture now — verify same action first).
4. **Pill BIGGER** (~44px tall for tappability, KEEP fixed/uniform across all 8 so no layout shift; scale internal glyphs; leave 18px serif title alone).
5. **Score pill → "add a new Suite"** (keeps `+`; the flow exists).
6. **Etude pill → "jump to Appearance section"** (keeps `+` — Alphonse reads `+` as "open an additional option"; the Appearance section exists).
- All 8 pills stay uniform WITH `+`, but each does something real (6 capture · Score add-Suite · Etude jump-Appearance). No dead buttons.

## SYMPHON — CURRENT STATE (live at sym.phon.se, v2.2.0)
- **✅ The 7 fire → rail → headers arc is COMPLETE.** Top strip coheres: logo INSIDE the rail as first non-tappable slot (hairline divider, Option B, geometry UNTOUCHED); rail at top; header = invitation title LEFT + date-under-title in accent + fixed 60×36 pill RIGHT.
- Invitation copy (all "verb your noun"): Aria "Note your ideas" · Presto "Pick your battles" · Herald "Herald your wins" · Overture "Chart your projects" · Score "Tune your structure" · Etude → "Shape your experience" (after Fire 8).
- **⚠️ §2.7 LOGO SPEC (FINAL — never redraw):** square icon, 4 see-saw lanes (Overture↔Libretto · Presto↔Nonet · Aria↔Score · Herald↔Etude), meaningful bar heights (Herald>Presto>Overture>Aria), keeps ORIGINAL coral **#E8836B** (not CVD #F26D3D). Inline SymphonMark SVG. MOVE it, never redraw.
- Design DNA: --aria:#F26D3D --libretto:#ADA23A --presto:#4FA377 --herald:#E3A857 --overture:#5B7FDE --nonet:#C9508F --score:#2E9BB8 --etude:#8B5FC9. Fonts Lora + Inter.
- **After Fire 8 / ongoing (NON-FIRE, no credits):** hand-reassignment of items onto Movements — usage, over ~1–2 weeks.

---

## DOMAIN ESTATE (live)
- **phon.se** — parent/self, LIVE (orbital-survey emblem + findings; noindex). Subdomains verified; Cloudflare proxy = faster.
- **sym.phon.se** — Symphon (work app), live.
- **aspect.sg** — the essay register (4 essays live) + the consultancy, forming.
- **alphonseyu.com** — gated CV.
- **nil.sg** — the useless wing (4 exhibits live).
- **Pending:** **anti.phon.se** (Antiphon, 18 Aug) · **al.phon.se** (reserved-to-defuse, no use yet).
- Naming: **sym**phon (work, together) + **anti**phon (reflection, answering) = call-and-response siblings.

## ASPECT° (aspect.sg) — the register
- 4 essays LIVE: №1 "Letting go of my friction" · №2 "Poke your head" · №3 "Being uncomfortable with discomfort" · №4 "Reduce the right friction". №5 = next when it comes.
- Phone-native publish: add `NNNN.md` to `src/essays/` in GitHub (private repo github.com/alphonseyu/aspect) → Cloudflare Pages auto-builds. Eleventy. **Single-quoted YAML** in front matter (hard-won fix).
- Composer tool at aspect.sg/compose generates valid front matter.
- Register discipline: no dates shown, numeric filenames, title-derived URLs, first para auto-splits as opening line, "## The Angle" marks the key insight line.
- **Rep proofreads essays** (flags spelling/typo/awkward as "problem" vs "preference" — never rewrites). Essays are HIS to write; Rep does NOT write them.

## nil.sg — THE USELESS WING (4 exhibits live)
- №01 **NULL** 🍅 — focus app you "win" by closing the tab.
- №02 **BIKES** 🦴 — joint-cracking overture (not bicycles).
- №03 **friction.observed** 🔥 — register of tiny injustices that INFLICTS a fresh friction when you try to log one (Aspect's evil twin; both anonymous, never seen together attributably — no conflict).
- №04 **FINAL** 📄 — file-naming tragedy; every save forces a worse name; "Final: never."
- №05 placeholder "akan datang".
- Pipeline: Dumb Dump → graduate ONE at a time (never flood). **BANKED (don't force):** Dormant (dormancy calculator), Meeting-That-Was-An-Email, Herald-but-honest, spurious-correlations. Secret theme: every exhibit is a joke about how Alphonse thinks.
- ⚠️ nil = playful wing ONLY; must NOT house Gramophone (tonally opposite).

## ANTIPHON (18 Aug, at anti.phon.se)
- **TOTALLY NEW build, separate Lovable project** (not the old Emberling project).
- ✅ **Emberling EXPORTED + DELETED (2 Aug)** — double-backed-up (Lovable export + all posts manually copied to Day One, verified). Chapter closed. Old project gone; its lovable.app subdomain released (not wanted).
- Concept: a reflective "notebook", dark-mode "reflection mode" direction explored. Details in ARCHIVE §3.

---

## THE CONSULTANCY & IDENTITY (forming — do NOT formalise on a high; one step at a time)
- **"Aspect Consultancy, as it always has been."** aspect.sg (owned since 2022) → the consultancy it was always meant to be. Write the essay first; don't leap to LLC/deck.
- **Identity:** not HR/builder/dev/tinkerer (those are the *how*). One word: **"different."** Three: **"Thinker, Doer, Believer."**
- **The operating manual > the product:** `how-i-think.md` ("The Operating Model") — how he thinks, the higher-value asset (generator not generated).
- **CONSULTANCY PRINCIPLES (durable):** (1) "Small numbers, large impact" — report outcomes not activity; a good fix nobody adopts is a hobby. (2) Show-hand is right — the work is the pitch, sidesteps the bluff, self-proving; "the pitch, it turns out, is a person." (3) Honest-counts discipline — never carry a number you can't stand behind; think-then-compress. (4) Sayings = compression artifacts of real thinking (earned first, compressed second).

## HELD SEEDS / DRAWER (captured, NOT to force-build)
- **"Observed & Owned"** (`observed-and-owned.html`) — the antiphonal portrait: Rep-OBSERVED (leads) + Alphonse-OWNED (answers), 6 pairs, brought current. Coda = two honest counts (7 major frictions in 12 years + 12 in 10 days; the gap IS the thesis). First real GRAMOPHONE-voice artifact / Aspect "about" seed. HELD — read unrushed, decide role in daylight.
- **Gramophone** — the living-record engine (`the-record-book-living.html`): plays the Record Book's groove back as public harmony. Record Book = the disc (private/raw); Gramophone = the player (public). Its own phon.se home someday.
- **3-way writing taxonomy (keep separate):** Aspect (serious/careful register) · nil (playful/nothing-serious) · Gramophone (purposeful/distilled craft-log).
- **al.phon.se** — reserved-to-defuse (close the mental loop so it stops nagging; NOT to develop). Principle: reserve-to-defuse is fine; the trap is build-to-justify.
- **Gut Feel** (gut.sg/gutfeel.sg held) — food directory idea, parked.
- **Next Aspect essay (HIS to write):** "knowing thyself before knowing how and why, to come up with the what" (inverts what→how→why).
- **"dark aspect"** — dark mode as a genuine second perspective (not cosmetic). Parked.

## SEALED / PRIVATE
- **`sealed-survey.html`** — full-numbers stats dossier (10 days: 3 sites, 19 dormant-years woken, ~50k words). SEALED/private, NOT public. Purpose: a reminder to appreciate & do better, for dejected/sian days. **Ritual: update WEEKLY on FRIDAYS** (the seam between draining week and free weekend).

## USAGE / TOOLING
- Alphonse hit Claude weekly limit ×2 (stats confirm) → **next session Wed 6pm** when it resets. Rationing until then.
- Getting a **separate GPT** for research/writing-research (e.g. escalator physics)/admin/nonsense — capability diversity + cross-checking. **THIS Claude stays PURE ESTATE-DEV** — don't let estate work drift to GPT.

---

## LORE (light)
"the Boob" (Book) → "handboob" (handoff). Domain-dormancy cliff: aspect.sg 4yr, alphonseyu.com 15yr, phon.se an evening, nil.sg <1hr. "Off-tangent, consistently." "Mr Claude" = the usage-cap authority (resets Wed 6pm). Fake-domain comedy (five.sg/tomato.sg etc — jokes, not bought).
